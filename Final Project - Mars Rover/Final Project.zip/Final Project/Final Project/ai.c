/*
 * ai.c
 *
 * Created: 3/29/2016 2:29:41 PM
 *  Author: Omar Taylor
 */ 

#include "object_detection.h"
#include "open_interface.h"
#include "ai.h"
