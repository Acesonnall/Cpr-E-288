/*
 * Final Project.c
 *
 * Created: 3/28/2016 2:00:15 PM
 * Author : Omar Taylor, Dalton Handel, Louis Hamilton, Souparni Agnihotri
 */ 

#include <avr/io.h>
#include "object_detection.h"
#include "open_interface.h"
#include "util.h"
#include "lcd.h"
#include "ai.h"

// Prototypes
void move(oi_t *self, double distance_mm);
void rotate(oi_t *self, double degrees);

int main(void)
{
	obstacle obst;
	reset(&obst);
    oi_t *sensor_data = oi_alloc();
    oi_init(sensor_data);
	
	unsigned char current;
	unsigned char num_notes = 3;
	unsigned char notes[] = {36, 36, 36};
	unsigned char duration[] = {15, 15, 15};
	
	while (1) {
		oi_update(sensor_data);
		/*lprintf("Cliff L: %d\nCliff Front L: %d\nCliff Front R: %d\nCliff R: %d", sensor_data->cliff_left_signal, sensor_data->cliff_frontleft_signal, sensor_data->cliff_frontright_signal, sensor_data->cliff_right_signal);
		lprintf("Cliff L: %d\nCliff Front L: %d\nCliff Front R: %d\nCliff R: %d", sensor_data->cliff_left, sensor_data->cliff_frontleft, sensor_data->cliff_frontright, sensor_data->cliff_right);
		wait_ms(100);*/
		current = USART_Receive();
		
		if (current == 'w') {
			move(sensor_data, 15);
		} else if (current == 's') {
			move(sensor_data, -15);
		} else if (current == 'a') {
			rotate(sensor_data, 45);
		} else if (current == 'd') {
			rotate(sensor_data, -45);
		} else if (current == 'q') {
			sweep(&obst);
			print_and_process_stats(&obst);
			//print_and_process_stats2_0(&obst);
			reset(&obst);
		} else {
			oi_load_song(2, num_notes, notes, duration);
			oi_play_song(2);
		}
		
		USART_Transmit(current);
	}
	
	return 0;
}

void move(oi_t *self, double distance_mm) { // Find more accurate way of moving robot
	double togo = distance_mm/0.115;   // calculated sensor distance
	double travel = 0;				// distance traveled by robot
	
	if (distance_mm > 0) {
		oi_set_wheels(150, 150);
		
		while (travel < togo) { // Cliff sensors currently calibrated for bot 11
			if ((self->cliff_frontleft_signal > 1000 || self->cliff_frontleft) || (self->cliff_frontright_signal > 900 || self->cliff_frontright)) {
				oi_set_wheels(-150, -150);
				wait_ms(1000);
				oi_set_wheels(0, 0);
				break;
			}
			
			if (self->cliff_left_signal > 500 || self->cliff_left) {
				rotate(self, -90);
				oi_set_wheels(150, 150);
				wait_ms(1000);
				oi_set_wheels(0, 0);
				rotate(self, 90);
				break;
			}
			
			if (self->cliff_right_signal > 500 || self->cliff_right) {
				rotate(self, 90);
				oi_set_wheels(150, 150);
				wait_ms(1000);
				oi_set_wheels(0, 0);
				rotate(self, -90);
				break;
			}
			
			if (self->bumper_left) {
				move(self, -15);
				travel -= 15.0/0.115;
				wait_ms(100);
				rotate(self, -90);
				wait_ms(100);
				break;
			}
			
			if (self->bumper_right) {
				move(self, -15);
				travel -= 15.0/0.115;
				wait_ms(100);
				rotate(self, 90);
				wait_ms(100);
				break;
			}
			oi_update(self);
			travel += self->distance;
		}
	} else if (distance_mm < 0) {
		oi_set_wheels(-150, -150);
		
		while (travel > togo) {
			oi_update(self);
			travel += self->distance;
		}
	}
	
	oi_set_wheels(0, 0);
}

void rotate(oi_t *self, double degrees) {
		double sensordegrees = degrees/1.13; //calibration: make number smaller to oversteer.
		double toturn = 0;
		
		if (degrees > 0){ //rotate CCW
			oi_set_wheels(150,-150);
			while (toturn < sensordegrees) {
				oi_update(self);
				toturn += self->angle;
			}
		}
		if (degrees < 0){ //rotate CW
			oi_set_wheels(-150,150);
			while (toturn > sensordegrees) {
				oi_update(self);
				toturn += self->angle;
			}
		}
		oi_set_wheels(0, 0); // stop
}

/************************************************************************/
/* Quits the program. Enabled by USART_Init                             */
/************************************************************************/
void quit()
{
	lprintf("Goodbye!"); // Goodbye lcd message
	char goodbyeTerminal[8] = "Goodbye!"; // Goodbye terminal message
	USART_Transmit('\r'); // Carriage return
	USART_Transmit('\n'); // New line
	USART_Transmit('\f'); // Clear terminal screen
	for (int i = 0; i < 8; i++)
	{
		USART_Transmit(goodbyeTerminal[i]); // Print message to terminal
	}
	wait_ms(5000);
	USART_Transmit('\f'); // Clear terminal
	lcd_clear(); // Clear LCD
}