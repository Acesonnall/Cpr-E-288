/*
 * object_detection.h
 *
 * Created: 3/28/2016 1:03:47 PM
 *  Author: Omar Taylor
 */ 

/* USART Bluetooth Definitions */
#define FOSC 16000000 // Clock Speed
#define BAUDBLUETOOTH 57600 // Bluetooth baud rate
#define UBRR FOSC/8/(BAUDBLUETOOTH-1) // Bluetooth Connection

/* Measurable Gap */
#define MAX_DETECTION_DISTANCE 80 // cm
#define MIN_DETECTION_DISTANCE 10 // cm

/* Object Linear Widths */
#define SMALL_OBJECT_SIZE_MIN 3   // Robot detects minimum linear width of smallest object as 3 cm
#define SMALL_OBJECT_SIZE_MAX 6   // Robot detects maximum linear width of smallest object as 6 cm
#define MEDIUM_OBJECT_SIZE_MIN 8  // Robot detects minimum linear width of medium object as 8 cm
#define MEDIUM_OBJECT_SIZE_MAX 10 // Robot detects maximum linear width of medium object as 11 cm, but will use 10 cm for the variable. Better to undershoot.
#define LARGE_OBJECT_SIZE_MIN 11  // Robot detects minimum linear width of largest object as 11 cm
#define LARGE_OBJECT_SIZE_MAX 21  // Robot detects maximum linear width of largest object as 21 cm

/* Definitions for All Objects Array Column Indices */
#define ALL_ANGULAR_WIDTH 0
#define ALL_LINEAR_WIDTH 1
#define ALL_DISTANCE_SONAR 2
#define ALL_DISTANCE_IR 3
#define ALL_POSITION 4

/* Definitions for Goal Post Array Column Indices */
#define GOALP_DISTANCE 0
#define GOALP_POSITION 1

/* Definitions for Obstacle Array Column Indices */
#define OBST_DISTANCE 0
#define OBST_POSITION 1

/* Compass Definitions for Object Arrays */
#define EAST 2
#define NORTH_EAST 3
#define NORTH 4
#define NORTH_WEST 5
#define WEST 6

/* Detection Variables */
typedef struct {
	volatile float degrees;
	
	/* IR Variables */
	volatile int cur_dist_IR;
	volatile int last_dist_IR;
	volatile int total_dist_IR;
	volatile char start_angle_IR;
	volatile char end_angle_IR;
	volatile char object_detected : 1;               // Can only process one object at a time
	volatile char cur_obj_size_IR : 5;               // Max object size is 17 cm
	
	/* SONAR Variables */
	volatile float cur_dist_SONAR;
	volatile float last_dist_SONAR;
	volatile char start_dist_SONAR;
	volatile char end_dist_SONAR;
	
	/* Smallest Object Variables */
	volatile char smallest_obj_angular_size : 6;
	volatile char smallest_obj_linear_size : 5; // Smallest possible object size is the max possible object size
	volatile char smallest_obj_dist_SONAR;
	volatile char smallest_obj_dist_IR;
	volatile float smallest_obj_position;
	
	/* Closest Object Variables */
	volatile char closest_obj_angular_size : 6; // Smallest possible object angle size is within 6 bits
	volatile char closest_obj_linear_size : 5; // Smallest possible object size is the max possible object size (17 for linear)
	volatile int closest_obj_dist_SONAR;
	volatile int closest_obj_dist_IR;
	volatile float closest_obj_position;
	
	/* Object Validation Level Variable */
	volatile char validation_level; // Validation level probably won't exceed 5 bits.
	
	/* Goal Post Variables to Analyze | Used in ai.c */
	volatile char goal_post_array[4][7]; // Each column stores information about the goal posts (4 total) distance, angular position, and compass direction
	volatile char goal_post_index : 3; // Amount of goal posts found. There are 4 posts total so 3 bits will suffice.
	
	/* Obstacle Variables to Analyze | Used in ai.c */
	volatile char obst_array[11][7]; // Each column stores information about the objects (11 total) distance, angular position, and compass direction
	volatile char obst_index : 3; // Amount of goal posts found. There are 4 posts total so 3 bits will suffice.
	
	/* Object Array Variables */
	volatile char all_objects_array[15][5]; // Array of objects sorted by index. Each column consists of two rows that store the objects size and distance
	volatile char all_object_index : 4;                  // Max amount of objects is ~14
	
	/* The Grid */
	volatile char grid[27][27]; // Map of 27x27 area around bot. Each grid point represents Sight distance of 80 cm. Maps location of objects based on direction and distance
} obstacle;

/************************************************************************/
/* Prepares LCD, IR, SONAR, Servo, USART, and object detection          */
/* structure                                                            */
/************************************************************************/
void initializations(obstacle* obst);

/************************************************************************/
/* Perform 180 degree sweep, finding the smallest and closest object in */
/* the process                                                          */
/************************************************************************/
void sweep(obstacle* obst);

/************************************************************************/
/* Finds the linear width of a detected object. Must have found         */
/* object's distance first. [sin((pi/180) * theta) * hypotenuse]        */
/************************************************************************/
char get_linear_width(obstacle* obst);

/************************************************************************/
/* Re-initialize everything and clear the object array                  */
/************************************************************************/
void reset(obstacle* obst);

/************************************************************************/
/* Find the smallest object out of the found objects                    */
/************************************************************************/
void find_smallest_obj(obstacle* obst);

/************************************************************************/
/* Find the any objects and log their stats in the object array         */
/************************************************************************/
void find_objs_IR(obstacle* obst);

/************************************************************************/
/* Finds and categorizes objects in obst->object_array                  */
/************************************************************************/
void analyze_found_objects(obstacle* obst);

/************************************************************************/
/* Find the closest object out of the found objects                     */
/************************************************************************/
void find_closest_obj(obstacle* obst);

/************************************************************************/
/* Show and tell, baby                                                  */
/************************************************************************/
void print_and_process_stats(obstacle* obst);

/************************************************************************/
/* Show and tell 2.0, baby                                              */
/************************************************************************/
void print_and_process_stats2_0(obstacle* obst);