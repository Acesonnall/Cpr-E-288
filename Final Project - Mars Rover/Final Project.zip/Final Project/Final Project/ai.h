/*
 * ai.h
 *
 * Created: 3/29/2016 2:29:58 PM
 *  Author: Omar Taylor
 */ 